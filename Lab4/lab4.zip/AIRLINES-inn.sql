use airlines;

SELECT DISTINCT aline.Name, aline.Abbr FROM airlines aline
   INNER JOIN flights f ON f.Airline = aline.Id
   WHERE f.Source = 'AXX' OR f.Destination = 'AXX'
   ORDER BY aline.Name;

SELECT DISTINCT f.FlightNo, f.Destination, port.Name FROM flights f
   INNER JOIN airports port ON port.Code = f.Destination
      INNER JOIN airlines aline ON aline.Id = f.Airline
   WHERE f.Source = 'AXX' AND aline.Abbr = 'Northwest'
   ORDER BY f.flightNo;

--NEED TO DO #3

--AND the rest