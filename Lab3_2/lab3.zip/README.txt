*****************************************************
CPE 365                               Michael Murdock
Cal Poly		  Computer Science Department
San Luis Obispo                College of Engineering 
California                   	 rmurdock@calpoly.edu   
*****************************************************
		   Main README
                   Version 1.0
		      Lab 3
                 October 4, 2017
*****************************************************