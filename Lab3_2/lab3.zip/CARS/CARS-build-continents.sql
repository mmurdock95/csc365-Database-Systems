INSERT INTO continents(continent) VALUES ('america');
INSERT INTO continents(continent) VALUES ('europe');
INSERT INTO continents(continent) VALUES ('asia');
INSERT INTO continents(continent) VALUES ('africa');
INSERT INTO continents(continent) VALUES ('australia');
