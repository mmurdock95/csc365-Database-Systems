#Michael Murdock
#rmurdock@calpoly.edu
#CSC365 EBuckalew
#Lab 2
DROP TABLE carsData;
DROP TABLE carNames;
DROP TABLE modelList;
DROP TABLE carMakers;
DROP TABLE countries;
DROP TABLE continents;