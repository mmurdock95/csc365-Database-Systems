#Michael Murdock
#rmurdock@calpoly.edu
#CSC365 EBuckalew
#Lab 2
DROP TABLE wine;
DROP TABLE grapes;
DROP TABLE appellations;