#Michael Murdock
#CSC365 EBuckalew
#Lab 2
DROP TABLE students;
DROP TABLE teachers;